import React from 'react'

function Footer() {
  return (
    <>
    <div className="footer">
        
        
          <span>
            © 2019 Snaxsmart.com. All Rights Reserved.
          </span>
    </div>
    </>
  )
}

export default Footer