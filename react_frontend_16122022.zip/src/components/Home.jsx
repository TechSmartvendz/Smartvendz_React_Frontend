import React from 'react'

function Home() {
  return (
    <div>
      <p>Home</p>
    </div>
  )
}

export default Home
