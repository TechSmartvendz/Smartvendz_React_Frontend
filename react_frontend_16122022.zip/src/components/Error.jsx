import React from 'react'

function Error() {
  return (
    <>
        
        <p>Oops, page not found</p>
    </>
  )
}

export default Error