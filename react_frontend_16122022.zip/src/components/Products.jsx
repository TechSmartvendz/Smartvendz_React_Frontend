import React from 'react'

function Products() {
  return (
    <>
      <p>Products</p>
    </>
  )
}

export default Products
